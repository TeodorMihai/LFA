#ifndef __STACK_H
#define __STACK_H 1

#include "list.h"
#include <stddef.h>

struct stack {
    size_t dim;
    struct cell* list;
};

struct stack* stack_init(size_t);
void stack_clean(struct stack*);

void stack_push(struct stack*, void*);
void stack_pop(struct stack*, void*);
void stack_top(struct stack*, void*);

int stack_is_empty(struct stack*);

#endif
