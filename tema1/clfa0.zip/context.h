#ifndef __CONTEXT_H
#define __CONTEXT_H 1

#include "stack.h"
#include "expression.h"

struct context {
    struct stack* opd;
    struct stack* opt;
    int state;
};

struct context* context_init();
void context_clean(struct context*);

void context_force(struct context*);
void context_collapse(struct context*);

#endif
