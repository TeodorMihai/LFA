#include "context.h"
#include <stdlib.h>

struct context* context_init(void)
{
    struct context* result = (struct context*)malloc(sizeof(*result));
    result->opd = stack_init(sizeof(struct expression*));
    result->opt = stack_init(sizeof(int));
    return result;
}

void context_clean(struct context* context)
{
    stack_clean(context->opd);
    stack_clean(context->opt);
    free(context);
}

int context_get_opt(struct context* context)
{
    int result;
    stack_pop(context->opt, &result);
    return result;
}


void context_force(struct context* context)
{
    int operator;
    struct expression *opd1, *opd2;
    stack_pop(context->opt, &operator);
    stack_pop(context->opd, &opd1);
    struct expression* result;
    switch(operator)
    {
        case KLEENE_EXPRESSION:
            result = exp_kleene_star(opd1);
            break;
        case UNION_EXPRESSION:
            stack_pop(context->opd, &opd2);
            result = exp_union(opd2, opd1);
            break;
        case CONCAT_EXPRESSION:
            stack_pop(context->opd, &opd2);
            result = exp_concat(opd2, opd1);
            break;
    }
    stack_push(context->opd, &result);
}

void context_collapse(struct context* context)
{
    while(!stack_is_empty(context->opt))
    {
        context_force(context);
    }
}
