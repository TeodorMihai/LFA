#include "stack.h"
#include <stdlib.h>
#include <string.h>

struct stack* stack_init(size_t dim)
{
    struct stack* result = (struct stack*)malloc(sizeof(*result));
    result->dim = dim;
    result->list = list_init();
    return result;
}

void stack_push(struct stack* stack, void* elem)
{
    void* copy = malloc(stack->dim);
    memcpy(copy, elem, stack->dim);
    list_add_last(stack->list, copy);
}

void stack_pop(struct stack* stack, void* elem)
{
    memcpy(elem, stack->list->prev->info, stack->dim);
    list_remove_last(stack->list);
}

void stack_top(struct stack* stack, void* elem)
{
    memcpy(elem, stack->list->prev->info, stack->dim);
}

int stack_is_empty(struct stack* stack)
{
    return list_is_empty(stack->list);
}

void stack_clean(struct stack* stack)
{
    list_clean(stack->list);
    free(stack);
}
