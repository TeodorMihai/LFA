#ifndef __DLIST_H
#define __DLIST_H 1

struct cell {
    void* info;
    struct cell* next;
    struct cell* prev;
};

struct cell* list_init(void);
void list_clean(struct cell*);

void list_add_last(struct cell*, void*);
void list_remove_last(struct cell*);

int list_is_empty(struct cell*);

#endif
