#include "expression.h"
#include <stdlib.h>
#include <stdio.h>

static struct expression* create_expression(int type, char value,\
        struct expression* left, struct expression* right)
{
    struct expression* result = (struct expression*)malloc(sizeof(*result));
    result->type = type;
    result->value = value;
    result->left = left;
    result->right = right;
    return result;
}

struct expression* exp_symbol(char c)
{
    return create_expression(SYMBOL_EXPRESSION, c, NULL, NULL);
}

struct expression* exp_void()
{
    return create_expression(VOID_EXPRESSION, 0, NULL, NULL);
}

struct expression* exp_null()
{
    return create_expression(NULL_EXPRESSION, 0, NULL, NULL);
}

struct expression* exp_union(struct expression* e1, struct expression* e2)
{
    return create_expression(UNION_EXPRESSION, 0, e1, e2);
}

struct expression* exp_concat(struct expression* e1, struct expression* e2)
{
    return create_expression(CONCAT_EXPRESSION, 0, e1, e2);
}

struct expression* exp_kleene_star(struct expression* e)
{
    return create_expression(KLEENE_EXPRESSION, 0, e, NULL);
}

int exp_check(struct expression* exp)
{
    if(exp == NULL)
    {
        return 0;
    }
    switch(exp->type)
    {
        case VOID_EXPRESSION:
        case NULL_EXPRESSION:
        case SYMBOL_EXPRESSION:
            return exp->left == NULL && exp->right == NULL;
        case KLEENE_EXPRESSION:
        case OPTIONAL_EXPRESSION:
        case PLUS_EXPRESSION:
            return exp->right == NULL && exp_check(exp->left);
        case UNION_EXPRESSION:
        case CONCAT_EXPRESSION:
            return exp_check(exp->left) && exp_check(exp->right);
    }
    return 0;
}
void exp_in_print_aux(struct expression* exp, int past)
{
    if(exp_priority(exp->type) < exp_priority(past))
    {
        printf("(");
    }
    switch(exp->type)
    {
        case VOID_EXPRESSION:
            printf("O");
            break;
        case NULL_EXPRESSION:
            printf("e");
            break;
        case SYMBOL_EXPRESSION:
            printf("%c", exp->value);
            break;
        case UNION_EXPRESSION:
            exp_in_print_aux(exp->left, exp->type);
            printf("|");
            exp_in_print_aux(exp->right, exp->type);
            break;
        case CONCAT_EXPRESSION:
            exp_in_print_aux(exp->left, exp->type);
            exp_in_print_aux(exp->right, exp->type);
            break;
        case KLEENE_EXPRESSION:
            exp_in_print_aux(exp->left, exp->type);
            printf("*");
            break;
        case PLUS_EXPRESSION:
            exp_in_print_aux(exp->left, exp->type);
            printf("+");
            break;
        case OPTIONAL_EXPRESSION:
            exp_in_print_aux(exp->left, exp->type);
            printf("?");
            break;
    }
    if(exp_priority(exp->type) < exp_priority(past))
    {
        printf(")");
    }
}
void exp_in_print(struct expression* exp)
{
    exp_in_print_aux(exp, UNION_EXPRESSION);
}

void exp_pre_print_aux(struct expression* exp, int type)
{
    if(exp->type != type)
    {
        exp_pre_print(exp);
    }
    else
    {
        exp_pre_print_aux(exp->left, type);
        printf(" ");
        exp_pre_print(exp->right);
    }
}
void exp_pre_print(struct expression* exp)
{
    switch(exp->type)
    {
        case VOID_EXPRESSION:
            printf("phi");
            return;
        case NULL_EXPRESSION:
            printf("epsilon");
            return;
        case SYMBOL_EXPRESSION:
            printf("(symbol %c)", exp->value);
            return;
    }
    printf("(");
    switch(exp->type)
    {
        case UNION_EXPRESSION:
            printf("union ");
            break;
        case CONCAT_EXPRESSION:
            printf("concat ");
            break;
        case KLEENE_EXPRESSION:
            printf("kleene ");
            exp_pre_print(exp->left);
            printf(")");
            return;
        case PLUS_EXPRESSION:
            printf("plus ");
            exp_pre_print(exp->left);
            printf(")");
            return;
        case OPTIONAL_EXPRESSION:
            printf("optional ");
            exp_pre_print(exp->left);
            printf(")");
            return;
    }
    exp_pre_print_aux(exp, exp->type);
    printf(")");
}

int exp_priority(int type)
{
    switch(type)
    {
        case UNION_EXPRESSION:
            return 0;
        case CONCAT_EXPRESSION:
            return 1;
        case KLEENE_EXPRESSION:
        case OPTIONAL_EXPRESSION:
        case PLUS_EXPRESSION:
            return 2;
        default:
            return 1000;
    }
}
