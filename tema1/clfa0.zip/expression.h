#ifndef __EXPRESSION_H
#define __EXPRESSION_H 1

#define VOID_EXPRESSION 0
#define NULL_EXPRESSION 1
#define SYMBOL_EXPRESSION 2
#define UNION_EXPRESSION 3
#define CONCAT_EXPRESSION 4
#define KLEENE_EXPRESSION 5
#define OPTIONAL_EXPRESSION 6
#define PLUS_EXPRESSION 7

struct expression {
    /*the type of an expression*/
    int type;

    struct expression* left;
    struct expression* right;

    /*in case the expression is a char*/
    char value;
};

struct expression* exp_symbol(char);
struct expression* exp_null();
struct expression* exp_void();
struct expression* exp_union(struct expression*, struct expression*);
struct expression* exp_concat(struct expression*, struct expression*);
struct expression* exp_kleene_star(struct expression*);
struct expression* exp_plus(struct expression*);
struct expression* exp_optional(struct expression*);

int exp_check(struct expression*);
void exp_in_print(struct expression*);
void exp_pre_print(struct expression*);

int exp_priority(int);

#endif
