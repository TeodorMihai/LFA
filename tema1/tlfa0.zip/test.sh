#!/bin/bash
# credits to AI :D
TEST_DIR=test
TEST_LIST=$TEST_DIR/tests
TEST_FILE=RE
OUT_FILE=PRE

# Compile student homework
# comment this if you use Java or Haskell - this means that the executable should be generated before running this script
make build

# Run tests
score=0
total_score=0
while read test_case
do
	# Parse the components of the line
	weight="$(echo $test_case | cut -d' ' -f 1)"
	input="$(echo $test_case | cut -d' ' -f 2)"
	output="$(echo $test_case | cut -d' ' -f 3)"

    #create a link to the current test file
    rm $TEST_FILE &> /dev/null
    ln -s -T $TEST_DIR/$input $TEST_FILE

	# Run the student homework
	make run 2>/dev/null | sed 1d >$output

	# Update scores
	total_score=$[$total_score + $weight]

    cmp -s $output $TEST_DIR/$output >/dev/null
	if [ $? -eq 0 ]
		then echo "Test $input->$output PASSED"; score=$[$score + $weight]; rm $output
		else echo "Test $input FAILED"; echo "failed output -> "$output; echo "official output -> "$TEST_DIR/$output
	fi
done < $TEST_LIST

rm $TEST_FILE &> /dev/null

grade=$[$score * 100 / $total_score]
echo "Score: " $grade " out of 100"
